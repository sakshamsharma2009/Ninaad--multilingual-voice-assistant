package com.example.ninadapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.PackageManagerCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;



public class MainActivity extends AppCompatActivity {

    int count=0;
    private FirebaseAuth mAuth;
    //private Button btnLogout;
    //ImageView voice_logo;
    EditText editText;
    ImageView imageView;
    public static final Integer RecordAudioRequestCode=1;

    private SpeechRecognizer speechRecognizer;
    AlertDialog.Builder alertSpeechDialog;
    AlertDialog alertDialog;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        mAuth=FirebaseAuth.getInstance();

        //sumeeet code
        editText=findViewById(R.id.editText);
        imageView=findViewById(R.id.imageView);


        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                !=PackageManager.PERMISSION_GRANTED){
            checkPermission();
        }
        speechRecognizer=SpeechRecognizer.createSpeechRecognizer(this);

        final Intent speechIntent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        /////////first page listeningggg
        speechRecognizer.startListening(speechIntent);
        final MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.beep);
        mediaPlayer.start();

        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);


        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
//
//        final MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.beep);
//        mediaPlayer.start();

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle bundle) {



            }

            @Override
            public void onBeginningOfSpeech() {
                if(count==0){
                    ViewGroup viewGroup=findViewById(android.R.id.content);
                    View dialogView= LayoutInflater.from(MainActivity.this).inflate(R.layout.alertcustom
                            ,viewGroup,false);
                }
                else
                {
                    ViewGroup viewGroup=findViewById(android.R.id.content);
                    View dialogView= LayoutInflater.from(MainActivity.this).inflate(R.layout.alertcustom
                            ,viewGroup,false);

                    alertSpeechDialog=new AlertDialog.Builder(MainActivity.this);
                    alertSpeechDialog.setMessage("Listening...");
                    alertSpeechDialog.setView(dialogView);
                    alertDialog=alertSpeechDialog.create();
                    alertDialog.show();
                }
                count+=1;
            }

            @Override
            public void onRmsChanged(float v) {

            }

            @Override
            public void onBufferReceived(byte[] bytes) {

            }

            @Override
            public void onEndOfSpeech() {
                speechRecognizer.startListening(speechIntent);
            }

            @Override
            public void onError(int i) {

            }

            @Override
            public void onResults(Bundle bundle) {
                imageView.setImageResource(R.drawable.ic_baseline_mic_24);
                ArrayList<String> arrayList=bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                editText.setText(arrayList.get(0));
                alertDialog.dismiss();

                String s= arrayList.get(0);
                if(s.equalsIgnoreCase("hello App")){
                    final MediaPlayer mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.beep);
                    mediaPlayer.start();
                    mediaPlayer.stop();
                }
                if (count<10) {
                    speechRecognizer.startListening(speechIntent);
                }
            }

            @Override
            public void onPartialResults(Bundle bundle) {

            }

            @Override
            public void onEvent(int i, Bundle bundle) {

            }
        });

        imageView.setOnTouchListener(new View.OnTouchListener() {


            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                if(motionEvent.getAction()==MotionEvent.ACTION_UP){
                    speechRecognizer.stopListening();
                }

                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){
                    imageView.setImageResource(R.drawable.ic_baseline_mic_24);
                    speechRecognizer.startListening(speechIntent);
                }
                return false;
            }
        });

    }

//    void initiate(){
//        speechRecognizer.startListening(speechIntent);
//    }

    //menu bar


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        menu.add("Login");
        menu.add("Register");
        menu.add("Logout");

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getTitle().equals("Login")){
            Toast.makeText(this, "LOGIN SELECTED", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();

        }
        else if (item.getTitle().equals("Register")){
            Toast.makeText(this, "REGISTER SELECTED", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            finish();
        }
        else if (item.getTitle().equals("Logout")){
            Toast.makeText(this, "LOGOUT SELECTED", Toast.LENGTH_SHORT).show();
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(MainActivity.this, MainActivity.class));
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    //sumeet out of oncreate
    private void checkPermission(){

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{
                    Manifest.permission.RECORD_AUDIO},RecordAudioRequestCode);
        }
    }

    @Override
    protected  void onDestroy(){
        super.onDestroy();
        speechRecognizer.destroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode==RecordAudioRequestCode && grantResults.length>0){
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"Permission Granted",Toast.LENGTH_SHORT).show();
            }
        }
    }

    //out of oncreate
//    @Override
//    public void onStart(){
//        super.onStart();
//        FirebaseUser currentUser= mAuth.getCurrentUser();
//        if (currentUser==null){
//            startActivity(new Intent(MainActivity.this, LoginActivity.class));
//        }
//
//    }

}